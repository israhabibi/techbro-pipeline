import React, { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Text, View, StyleSheet, Platform } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import Colors from "@/constants/colors";
import { getApiUrl } from "@/lib/query-client";
import type { Achievement, GradeEntry, JurusanSelection, ProgramStudi, StudentData } from "@/lib/consultation-context";

type AiSurface = "dashboard" | "analysis" | "consultation";

interface RealtimeAiProps {
  surface: AiSurface;
  studentData: StudentData;
  grades: GradeEntry[];
  achievements: Achievement[];
  selections: [JurusanSelection | null, JurusanSelection | null];
  averageGrade: number;
  masterData: ProgramStudi[];
}

function buildContext(props: RealtimeAiProps) {
  return {
    surface: props.surface,
    studentData: props.studentData,
    grades: props.grades,
    achievements: props.achievements,
    selections: props.selections.filter(Boolean),
    averageGrade: props.averageGrade,
    // Kirim data aktual yang relevan tanpa membebani permintaan AI.
    masterData: props.masterData.slice(0, 80),
  };
}

export function RealtimeAiInsight(props: RealtimeAiProps) {
  const [insight, setInsight] = useState("");
  const [updatedAt, setUpdatedAt] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const context = useMemo(() => buildContext(props), [
    props.surface, props.studentData, props.grades, props.achievements,
    props.selections, props.averageGrade, props.masterData,
  ]);
  const fingerprint = JSON.stringify(context);

  useEffect(() => {
    const controller = new AbortController();
    const timer = setTimeout(async () => {
      setLoading(true);
      setError(false);
      try {
        const url = Platform.OS === "web" ? "/api/ai/realtime-insight" : `${getApiUrl()}/api/ai/realtime-insight`;
        const response = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(context),
          signal: controller.signal,
        });
        if (!response.ok) throw new Error(`AI ${response.status}`);
        const data = await response.json();
        setInsight(data.insight || "Belum ada insight yang bisa diberikan.");
        setUpdatedAt(data.updatedAt || new Date().toISOString());
      } catch (err: any) {
        if (err?.name !== "AbortError") setError(true);
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }, 850);

    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [fingerprint]);

  return (
    <View style={styles.card}>
      <View style={styles.heading}>
        <View style={styles.icon}><Ionicons name="sparkles" size={17} color={Colors.white} /></View>
        <View style={styles.headingText}>
          <Text style={styles.title}>Insight AI Real-time</Text>
          <Text style={styles.caption}>Diperbarui otomatis saat informasi berubah</Text>
        </View>
        {loading && <ActivityIndicator size="small" color={Colors.primary} />}
      </View>
      {error ? (
        <Text style={styles.muted}>Insight sementara belum tersedia. Data aplikasi tetap tersimpan dan analisis lokal tetap berjalan.</Text>
      ) : insight ? (
        <Text style={styles.insight}>{insight}</Text>
      ) : (
        <Text style={styles.muted}>AI sedang membaca informasi terbaru...</Text>
      )}
      {!!updatedAt && !loading && (
        <Text style={styles.updated}>Terakhir diperbarui {new Date(updatedAt).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#f8f5ff",
    borderWidth: 1,
    borderColor: "#e9d5ff",
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
  },
  heading: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 10 },
  icon: { width: 32, height: 32, borderRadius: 10, backgroundColor: "#7c3aed", justifyContent: "center", alignItems: "center" },
  headingText: { flex: 1 },
  title: { fontSize: 15, fontFamily: "Inter_700Bold", color: "#4c1d95" },
  caption: { fontSize: 11, fontFamily: "Inter_400Regular", color: "#7c3aed", marginTop: 2 },
  insight: { fontSize: 14, lineHeight: 21, fontFamily: "Inter_500Medium", color: Colors.text },
  muted: { fontSize: 13, lineHeight: 19, fontFamily: "Inter_400Regular", color: Colors.textSecondary },
  updated: { fontSize: 10, fontFamily: "Inter_400Regular", color: "#8b5cf6", marginTop: 9 },
});