# Konsultasi SNBP — Deploy Package

## Isi folder
- `index.html` — entrypoint web app
- `_expo/` — JS bundle + assets
- `assets/` — gambar/icon
- `favicon.ico`
- `metadata.json` — app manifest
- `Dockerfile` — image definition
- `docker-compose.yml` — compose minimal
- `DEPLOY.md` — panduan ini

## Opsi A: Docker (recommended)
### Di server tujuan
1. Install Docker + Docker Compose
2. Copy folder ini ke server
3. Build + start:
   ```bash
   docker compose up -d --build
   ```
4. Cek:
   ```bash
   curl http://localhost/
   ```

### Reverse proxy (optional)
- Kalau pakai nginx/traefik/Caddy, arahkan domain ke container `snbp-web` port 80
- HTTPS: generate cert via certbot/Caddy/LE di server tujuan

## Opsi B: Tanpa Docker
### Di server tujuan
1. Copy folder ini ke `/var/www/snbp`
2. Install nginx:
   ```bash
   apt update && apt install -y nginx
   ```
3. Buat config:
   ```bash
   cat > /etc/nginx/sites-available/snbp <<'EOF'
   server {
     listen 80;
     server_name _;
     root /var/www/snbp;
     index index.html;
     location / { try_files $uri $uri/ /index.html; }
   }
   EOF
   ln -sf /etc/nginx/sites-available/snbp /etc/nginx/sites-enabled/
   nginx -t && systemctl reload nginx
   ```
4. Cek:
   ```bash
   curl http://localhost/
   ```

## Ukuran
- ~3.4 MB (hanya file yang dibutuhkan)
- Tidak include source code/build cache

## Update
- Ganti isi folder dengan versi baru
- `docker compose up -d --build` (opsi A)
- `systemctl reload nginx` (opsi B)
